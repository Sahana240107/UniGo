import Link from "next/link";

const TILES = [
  {
    href: "/community/organization",
    emoji: "🎓",
    title: "Organisation",
    subtitle:
      "Verify your work or college email to join your institution's pool",
    badge: "Strongest trust",
    badgeBg: "bg-[#EAE8FF]",
    badgeColor: "text-[#6C63FF]",
    borderColor: "border-[#6C63FF]",
  },
  {
    href: "/community/neighbourhood",
    emoji: "📍",
    title: "Neighbourhood",
    subtitle:
      "Enter your area and confirm with GPS to join your locality pool",
    badge: "GPS confirmed",
    badgeBg: "bg-[#DCFCE7]",
    badgeColor: "text-[#166534]",
    borderColor: "border-[#22C55E]",
  },
  {
    href: "/community/invitecode",
    emoji: "👥",
    title: "TrustCircle",
    subtitle:
      "Have an invite code? Join a private circle — or create your own",
    badge: "Private group",
    badgeBg: "bg-[#FEF3C7]",
    badgeColor: "text-[#92400E]",
    borderColor: "border-[#F59E0B]",
  },
];

export default function JoinCommunityPage() {
  return (
    <main className="min-h-screen bg-[#F8F7FF] px-5 py-10">
      <section className="mx-auto max-w-2xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-extrabold text-[#1A1A2E] tracking-tight">
            Join Your Communities
          </h1>
          <p className="mt-3 text-[15px] text-[#6B6B8A] leading-relaxed max-w-lg">
            Choose who you want to carpool with. Each layer you join expands
            your matching pool. You need at least one to continue.
          </p>
        </div>

        {/* Top row: Organisation + Neighbourhood */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          {TILES.slice(0, 2).map((tile) => (
            <Link
              key={tile.href}
              href={tile.href}
              className={`group flex flex-col bg-white rounded-2xl p-5 border-[1.5px] ${tile.borderColor} shadow-sm hover:shadow-md transition-shadow`}
            >
              <span className="text-4xl mb-3">{tile.emoji}</span>
              <span className="text-[16px] font-extrabold text-[#1A1A2E] mb-2">
                {tile.title}
              </span>
              <span className="text-[13px] text-[#6B6B8A] leading-[1.5] mb-4 flex-1">
                {tile.subtitle}
              </span>
              <span
                className={`self-start text-[11px] font-extrabold tracking-wide px-2.5 py-1 rounded-md ${tile.badgeBg} ${tile.badgeColor}`}
              >
                {tile.badge}
              </span>
            </Link>
          ))}
        </div>

        {/* Bottom row: TrustCircle centred */}
        <div className="flex justify-center mb-8">
          <Link
            href={TILES[2].href}
            className={`flex flex-col items-center bg-white rounded-2xl p-5 border-[1.5px] ${TILES[2].borderColor} shadow-sm hover:shadow-md transition-shadow w-[55%]`}
          >
            <span className="text-4xl mb-3">{TILES[2].emoji}</span>
            <span className="text-[16px] font-extrabold text-[#1A1A2E] mb-2">
              {TILES[2].title}
            </span>
            <span className="text-[13px] text-[#6B6B8A] leading-[1.5] text-center mb-4">
              {TILES[2].subtitle}
            </span>
            <span
              className={`text-[11px] font-extrabold tracking-wide px-2.5 py-1 rounded-md ${TILES[2].badgeBg} ${TILES[2].badgeColor}`}
            >
              {TILES[2].badge}
            </span>
          </Link>
        </div>

        <p className="text-center text-[12px] text-[#A0A0B8] leading-relaxed">
          You can join multiple communities and add more any time from your
          Profile.
        </p>
      </section>
    </main>
  );
}